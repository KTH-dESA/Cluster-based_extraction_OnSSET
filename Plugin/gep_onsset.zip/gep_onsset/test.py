l = QgsVectorLayer(r'F:\Zambia\1\Assist\ewfg.shp','test')

if not l.isEditable():
    l.startEditing()

for field in l.fields():
    if field.name() == "_mean_4":
        with edit(l):
            idx = l.fields().indexFromName(field.name())
            l.changeAttributeValue(idx, 3, 512)

l.commitChanges()